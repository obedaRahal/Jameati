// import 'package:flutter/material.dart';
// import 'package:get/get.dart';
// import 'package:project_manag_ite/bindings/initial_binding.dart';
// import 'package:project_manag_ite/controller/serv/theme_controller.dart';
// import 'package:project_manag_ite/core/constant/route_name.dart';
// import 'package:project_manag_ite/core/services/services.dart';
// import 'package:project_manag_ite/routes.dart';

// void main() async {
//   WidgetsFlutterBinding.ensureInitialized();
//   await initialServices();

//   Get.put(ThemeController());
//   runApp(const MyApp());
// }

// class MyApp extends StatelessWidget {
//   const MyApp({super.key});

//   @override
//   Widget build(BuildContext context) {
    
//     return Obx(() {
//       final theme = Get.find<ThemeController>().theme.value;
//       return GetMaterialApp(
//         debugShowCheckedModeBanner: false,
//         title: 'Project Management',
//         theme: theme,
//         getPages: routes,
//         initialBinding: InitialBindings(),
//       );
//     });
//   }
// }



import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:project_manag_ite/bindings/initial_binding.dart';
import 'package:project_manag_ite/controller/serv/theme_controller.dart';
import 'package:project_manag_ite/core/services/services.dart';
import 'package:project_manag_ite/routes.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await initialServices();


  Get.put(ThemeController());
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    
//     return Obx(() {
//       final theme = Get.find<ThemeController>().theme.value;
//       return GetMaterialApp(
//         debugShowCheckedModeBanner: false,
//         title: 'Project Management',
//         theme: theme,
//         getPages: routes,
//         initialBinding: InitialBindings(),
//       );
//     });
//   }
// }


return Obx(() {
      final theme = Get.find<ThemeController>().theme.value;

      return ScreenUtilInit(
          designSize: Size(393, 873), // حجم التصميم المرجعي الذي صممت عليه
        minTextAdapt: true,
        splitScreenMode: true,
        builder: (context, child) {
          return GetMaterialApp(
            debugShowCheckedModeBanner: false,
            title: 'Project Management',
            theme: theme,
            getPages: routes,
            initialBinding: InitialBindings(),
          );
        },
      );
    });
  }
}
