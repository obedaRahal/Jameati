class AppLink {
  //static const String server = "http://localhost/api" ;
  static const String server = "http://10.0.2.2/api" ;

  // auth 
  static const String registerApi = "$server/student/register" ;
  static const String verifyRegisterApi = "$server/student/verifyOtp" ;
  static const String resendCodeVerifyAtRegisterApi = "$server/student/resendOtp" ;
  static const String loginApi = "$server/student/login" ;

  static const String forgetPasswordApi = "$server/student/forgetPassword/sendOtp" ;
  static const String verifyCodeforgetPasswordApi = "$server/student/forgetPassword/verifyOtp" ;
  static const String resendCodeVerifyAtForgetpasswordApi = "$server/student/forgetPassword/resendOtp" ;
  static const String newPasswordApi = "$server/student/forgetPassword/resetPassword" ;

}