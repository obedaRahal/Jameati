// import 'dart:convert';

// import 'package:dartz/dartz.dart';
// import 'package:flutter/material.dart';
// import 'package:project_manag_ite/core/class/status_request.dart';
// import 'package:project_manag_ite/core/functions/check_internet.dart';
// import 'package:http/http.dart' as http;

// class Crud {
//   Future<Either<StatusRequest, Map>> postData(String linkurl, Map data) async {
//     try {
//       if (await checkInternet()) {
//         debugPrint("============im at crud and there is internet");

//         var response = await http.post(Uri.parse(linkurl), body: data);
//         if (response.statusCode == 200 || response.statusCode == 201) {
//           debugPrint(
//               "============im at crud and status code is ${response.statusCode}");
//           Map responsebody = jsonDecode(response.body);
//           return Right(responsebody);
//         } else {
//           debugPrint(
//               "============im at crud and status code is ${response.statusCode}");
//           return const Left(StatusRequest.serverfaliure);
//         }
//       } else {
//         debugPrint("============im at crud and there is no internet");
//         return const Left(StatusRequest.offlinefailure);
//       }
//     } catch (_) {
//       debugPrint("============im at crud at catch and StatusRequest is {} ");

//       return const Left(StatusRequest.serverfaliure);
//     }
//   }
// }

import 'dart:convert';
import 'package:dartz/dartz.dart';
import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;
import 'package:project_manag_ite/core/class/status_request.dart';
import 'package:project_manag_ite/core/functions/check_internet.dart';

class Crud {
  Future<Either<StatusRequest, Map>> postData({
    required String url,
    required Map<String, String> body,
    bool useMultipart = false,
    Map<String, String>? headers,
    Map<String, String>? files,
  }) async {
    try {
      if (!await checkInternet()) {
        return const Left(StatusRequest.offlinefailure);
      }

      http.Response response;

      if (useMultipart) {
        var uri = Uri.parse(url);
        var request = http.MultipartRequest('POST', uri);
        request.fields.addAll(body);
        if (files != null) {
          for (var entry in files.entries) {
            request.files
                .add(await http.MultipartFile.fromPath(entry.key, entry.value));
          }
        }
        if (headers != null) {
          request.headers.addAll(headers);
        }
        var streamed = await request.send();
        response = await http.Response.fromStream(streamed);
      } else {
        response = await http.post(
          Uri.parse(url),
          headers: headers ?? {"Content-Type": "application/json"},
          body: jsonEncode(body),
        );
      }

      debugPrint("✅ Status Code: ${response.statusCode}");
      debugPrint("✅ Response Body: ${response.body}");

      Map responseBody = {};

      try {
        responseBody = jsonDecode(response.body);
      } catch (e) {
        debugPrint("❌ Failed to decode JSON: $e");
        responseBody = {
          "title": "خطأ داخلي",
          "body": "حدث خطأ غير متوقع في الاستجابة",
          "status_code": response.statusCode
        };
      }

      return Right(responseBody); // نُعيد الاستجابة مهما كانت
    } catch (e) {
      debugPrint("❌ Error in postData ar crud : $e");
      return const Left(StatusRequest.serverfaliure);
    }
  }
}
