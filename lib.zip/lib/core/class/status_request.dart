enum StatusRequest {
  none,
  loading , 
  success , 
  failure , 
  serverfaliure , 
  offlinefailure
}