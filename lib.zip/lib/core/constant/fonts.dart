class MyFonts {
  static const aeonic = 'Aeonic' ;

  static const hekaya = 'Hekaya' ;
}