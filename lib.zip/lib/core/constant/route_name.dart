class AppRoute {

  //// auth
  static const String onBoarding = "/onBoarding" ;
  static const String login = "/login" ;
  static const String register = "/register" ;
  static const String welccm = "/welcom" ;
  static const String loginregister = "/loginregister" ;
  static const String verificationRegister = "/verificationRegister" ;
  static const String forgetPassword1 = "/forgetPassword1" ;
  static const String forgetPassword2 = "/forgetPassword2" ;
  static const String forgetPassword3 = "/forgetPassword3" ;

  ///////// home
  static const String home = "/home" ;
  static const String navBar = "/navBar" ;
  static const String chats = "/chats" ;

}