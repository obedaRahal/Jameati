// import 'package:flutter/material.dart';
// import 'package:project_manag_ite/core/constant/fonts.dart';

// class AppTheme {
//   // Light Theme
//   static ThemeData lightTheme = ThemeData(
//     fontFamily: MyFonts.hekaya,
//     brightness: Brightness.light,
//     scaffoldBackgroundColor: const Color(0xFFFFFFFF),
//     primaryColor: const Color(0xFF29B6F6),
//     inputDecorationTheme:const InputDecorationTheme(
//       fillColor:  Color(0xFFE7E7E7),
//       hintStyle: TextStyle(color: Color(0xFFACACAC)),
//     ),
//     textTheme: const TextTheme(
//       bodyMedium: TextStyle(color: Color(0xFF121212)),
//     ),
//     elevatedButtonTheme: ElevatedButtonThemeData(
//       style: ElevatedButton.styleFrom(
//         backgroundColor:const Color(0xFF29B6F6),
//         foregroundColor: Colors.white,
//       ),
//     ),
//   );

//   // Dark Theme
//   static ThemeData darkTheme = ThemeData(
//     fontFamily: MyFonts.hekaya,
//     brightness: Brightness.dark,
//     scaffoldBackgroundColor: const Color(0xFF121212),
//     primaryColor: const Color(0xFF81d4fa),
//     inputDecorationTheme:const InputDecorationTheme(
//       fillColor: Color(0xFF2F2F2F),
//       hintStyle: TextStyle(color: Color(0xFF7E7E7E)),
//     ),
//     textTheme: const TextTheme(
//       bodyLarge: TextStyle(color: Colors.white),
//       bodyMedium: TextStyle(color: Colors.white),
      
//     ),
//     elevatedButtonTheme: ElevatedButtonThemeData(
//       style: ElevatedButton.styleFrom(
//         backgroundColor:const Color(0xFF81d4fa),
//         foregroundColor: Colors.black,
//       ),
//     ),
//   );
// }


import 'package:flutter/material.dart';
import 'package:project_manag_ite/core/constant/colors.dart';
import 'package:project_manag_ite/core/constant/fonts.dart';


class AppTheme {
  static ThemeData lightTheme = ThemeData(
    fontFamily: MyFonts.hekaya,
    brightness: Brightness.light,
    scaffoldBackgroundColor: AppColors.white,
    primaryColor: AppColors.primary,
    extensions:  [CustomAppColors.light],
  );

  static ThemeData darkTheme = ThemeData(
    fontFamily: MyFonts.hekaya,
    brightness: Brightness.dark,
    scaffoldBackgroundColor: AppColors.black,
    primaryColor: AppColors.darkPrimary,
    extensions:  [CustomAppColors.dark],
  );
}
