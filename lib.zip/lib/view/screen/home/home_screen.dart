import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:project_manag_ite/controller/nav_bar/home/home_controller.dart';
import 'package:project_manag_ite/controller/serv/theme_controller.dart';
import 'package:project_manag_ite/core/constant/colors.dart';
import 'package:project_manag_ite/core/constant/image_asset.dart';
import 'package:project_manag_ite/data/datasource/static/static.dart';
import 'package:project_manag_ite/view/widget/home/best_marks_carosal_slider.dart';
import 'package:project_manag_ite/view/widget/home/custom_indicator_with_text_row.dart';
import 'package:project_manag_ite/view/widget/home/custom_select_button.dart';
import 'package:project_manag_ite/view/widget/home/form_submit_widget_in_row.dart';
import 'package:project_manag_ite/view/widget/home/image_card_widget_home.dart';
import 'package:project_manag_ite/view/widget/home/new_ads_and_ads_text_row.dart';
import 'package:project_manag_ite/view/widget/home/notificat_name_profile_row.dart';
import 'package:project_manag_ite/view/widget/home/statistic_all_row.dart';
import 'package:project_manag_ite/view/widget/onBoaringWidget/custom_title_text.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).extension<CustomAppColors>()!;
    double heightMediaQ = MediaQuery.of(context).size.height;
    final controller = Get.find<HomeControllerImp>();

    final List<int> years = [2024, 2023, 2022, 2021];

    return SafeArea(
      child: Padding(
        padding: EdgeInsets.only(
          top: 18.h,
          left: 18.h,
          right: 18.h,
        ),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              NotificationNameProfileRow(
                //heightMediaQ: heightMediaQ,
                colors: colors,
              ),
              IconButton(
                icon: Icon(
                  Get.find<ThemeController>().isDark
                      ? Icons.light_mode
                      : Icons.dark_mode,
                ),
                onPressed: () => Get.find<ThemeController>().toggleTheme(),
              ),
              SizedBox(
                height: 30.h,
              ),
              NewAdsAndAdsTextRow(
                //heightMediaQ: heightMediaQ,
                colors: colors,
              ),
              SizedBox(
                height: 10.h,
              ),
              ImageCardWidgetRow(),
              SizedBox(
                height: 20.h,
              ),
              CustomIndicatorWithTextRow(
                text: "من أجلك",
                pageController: controller.pageController,
                //heightMediaQ: heightMediaQ,
              ),
              // const SizedBox(
              //   height: 10,
              // ),
              FormSubmitWidgetRowwww(),
              SizedBox(
                height: 20.h,
              ),
              CustomTitleText(
                  text: "احصائيات",
                  isTitle: true,
                  screenHeight: 600.sp,
                  textColor: colors.titleText,
                  textAlign: TextAlign.center),
              SizedBox(
                height: 10.h,
              ),
              StatisticAllRow(),
              SizedBox(
                height: 20.h,
              ),
              Obx(
                () => CustomIndicatorWithTextRow(
                  pageCount: staticSliderData.length,
                  text: "الأعلى تقييما",
                  pageController: PageController(
                    initialPage: controller.carouselCurrentIndex.value,
                  ),
                  //heightMediaQ: heightMediaQ,
                  textDirection: TextDirection.rtl,
                ),
              ),
              Obx(() => SingleChildScrollView(
                    padding: const EdgeInsets.symmetric(vertical: 10),
                    scrollDirection: Axis.horizontal,
                    child: Directionality(
                      textDirection: TextDirection.rtl,
                      child: Row(
                        children: [
                          for (final year in years)
                            CustomSelectButton(
                              colors: colors,
                              text: '$year',
                              isSelected: controller.selectedYear.value == year,
                              onTap: () {
                                controller.selectedYear.value = year;
                                // نفذ هنا منطق التحديث إن وُجد
                                print("تم اختيار السنة: $year");
                              },
                            ),
                        ],
                      ),
                    ),
                  )),
              BestMarkCarosalSlider(),
              SizedBox(
                height: 30.h,
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class ImageCardWidgetRow extends StatelessWidget {
  const ImageCardWidgetRow({super.key});

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).extension<CustomAppColors>()!;

    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        ImageCardWidget(
          backgroundColor: Get.find<ThemeController>().isDark
              ? AppColors.darkPrimary
              : AppColors.yellowWhite,
          iconAsset: MyImageAsset.imgIcon,
          numberText: "899",
          backgroundNumberText: Get.find<ThemeController>().isDark
              ? AppColors.yellow
              : AppColors.white,
          titleText: "صور",
          titleTextColor: AppColors.yellow,
          imageAsset: MyImageAsset.photoImage,
          //heightMediaQ: MediaQuery.of(context).size.height,
        ),
        ImageCardWidget(
          backgroundColor: colors.cyenToWhite_greyInputDark,
          iconAsset: MyImageAsset.pdfIcon,
          numberText: "899",
          backgroundNumberText: Get.find<ThemeController>().isDark
              ? AppColors.cyen
              : AppColors.white,
          titleText: "ملفات",
          titleTextColor: AppColors.cyen,
          imageAsset: MyImageAsset.pdfImage,
          //heightMediaQ: MediaQuery.of(context).size.height,
        )
      ],
    );
  }
}
