
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:project_manag_ite/controller/serv/theme_controller.dart';
import 'package:project_manag_ite/core/constant/colors.dart';
import 'package:project_manag_ite/view/widget/onBoaringWidget/custom_title_text.dart';

class CustomSelectButton extends StatelessWidget {
  final String text;
  final bool isSelected;
  final VoidCallback onTap;
  final CustomAppColors colors;

  const CustomSelectButton({
    super.key,
    required this.text,
    required this.isSelected,
    required this.onTap,
    required this.colors,
  });

  @override
  Widget build(BuildContext context) {
    final isDark = Get.find<ThemeController>().isDark;

    return GestureDetector(
      onTap: onTap,
      child: Padding(
        padding: const EdgeInsets.only(left: 9),
        child: Container(
          decoration: BoxDecoration(
            color: isSelected 
            ?(isDark?AppColors.cyen: AppColors.cyenToWhite )
            : (isDark?AppColors.darkPrimary: AppColors.grey),
            borderRadius: BorderRadius.circular(20),
            // border: Border.all(
            //   color: isSelected ? Colors.transparent : Colors.blue,
            // ),
          ),
          child: CustomTitleText(
            horizontalPadding: 15,
            text: text,
            isTitle: true,
            screenHeight: MediaQuery.of(context).size.height * .45,
            textAlign: TextAlign.center,
            textColor: isSelected
                ? (isDark ? AppColors.black : AppColors.primary)
                : AppColors.greyHintLight,
          ),

          //Text(
          //   yearText,
          //   style: const TextStyle(
          //     fo
          //     fontSize: 16,
          //     fontFamily: 'OleoScript',
          //   ).copyWith(
          //     color: isSelected ? AppColors.primary : AppColors.greyHintLight,
          //   ),
          // ),
        ),
      ),
    );
  }
}
