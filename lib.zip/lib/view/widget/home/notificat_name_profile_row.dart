// import 'package:flutter/material.dart';
// import 'package:flutter_screenutil/flutter_screenutil.dart';
// import 'package:project_manag_ite/core/constant/colors.dart';
// import 'package:project_manag_ite/view/widget/home/custom_background_with_child.dart';
// import 'package:project_manag_ite/view/widget/onBoaringWidget/custom_title_text.dart';

// class NotificationNameProfileRow extends StatelessWidget {
//   const NotificationNameProfileRow({super.key, required this.colors});
//   //final double heightMediaQ;
//   final CustomAppColors colors;

//   @override
//   Widget build(BuildContext context) {

//     return Row(
//       children: [
//         CustomBackgroundWithWidget(
//           height: 60.h,
//           width: 60.h,
//           color: colors.greyBackgrondHome_darkPrimary,
//           borderRadius: 45,
//           child: Icon(
//             Icons.notifications_none_outlined,
//             size: 40.h,
//             color: AppColors.greyHintLight,
//           ),
//         ),
//         const Spacer(),
//         CustomBackgroundWithWidget(
//             height: 45.h,
//             width: 190.w,
//             color: colors.greyBackgrondHome_darkPrimary,
//             borderRadius: 45,
//             alignment: Alignment.centerRight,
//             child: CustomTitleText(
//               horizontalPadding: 15.h,
//               text: "مرحبا , عبيده الرحال",
//               isTitle: true,
//               screenHeight: 400.sp,
//               textAlign: TextAlign.center,
//               textColor: AppColors.greyHintLight,
//             )),
//         SizedBox(
//           width: 10.h,
//         ),
//         CustomBackgroundWithWidget(
//           height: 60.h,
//           width: 60.h,
//           color: colors.greyBackgrondHome_darkPrimary,
//           borderRadius: 45,
//           child: Icon(
//             Icons.group,
//             size: 35.h,
//             color: AppColors.greyHintDark,
//           ),
//         ),
//       ],
//     );
//   }
// }

import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:project_manag_ite/core/constant/colors.dart';
import 'package:project_manag_ite/core/services/services.dart';
import 'package:project_manag_ite/view/widget/home/custom_background_with_child.dart';
import 'package:project_manag_ite/view/widget/onBoaringWidget/custom_title_text.dart';

class NotificationNameProfileRow extends StatelessWidget {
  const NotificationNameProfileRow({super.key, required this.colors});
  final CustomAppColors colors;

  @override
  Widget build(BuildContext context) {
    final myServices = Get.find<MyServices>();

    // استرجاع الاسم والصورة من SharedPreferences
    final String name = myServices.sharedPreferences.getString("name") ?? "اسم";
    final String profileImage =
        myServices.sharedPreferences.getString("profile_image") ?? "";

    return Row(
      children: [
        // أيقونة الإشعارات
        CustomBackgroundWithWidget(
          height: 60.h,
          width: 60.h,
          color: colors.greyBackgrondHome_darkPrimary,
          borderRadius: 45,
          child: Icon(
            Icons.notifications_none_outlined,
            size: 40.h,
            color: AppColors.greyHintLight,
          ),
        ),

        const Spacer(),

        // عرض الاسم
        // CustomBackgroundWithWidget(
        //   height: 45.h,
        //   width: 190.w,
        //   color: colors.greyBackgrondHome_darkPrimary,
        //   borderRadius: 45,
        //   alignment: Alignment.bottomRight,
        //   child: CustomTitleText(
        //     horizontalPadding: 15.h,
        //     text: " $name , مرحبا ",
        //     isTitle: true,
        //     screenHeight: 400.sp,
        //     textAlign: TextAlign.center,
        //     textColor: AppColors.greyHintLight,
        //   ),
        // ),

        CustomBackgroundWithWidget(
            height: 45.h,
            width: 190.w,
            color: colors.greyBackgrondHome_darkPrimary,
            borderRadius: 45,
            alignment: Alignment.centerRight,
            child: CustomTitleText(
              horizontalPadding: 15.h,
              text: " $name",
              isTitle: true,
              maxLines: 1,
              screenHeight: 400.sp,
              textAlign: TextAlign.center,
              textColor: AppColors.greyHintLight,
            )),

        SizedBox(width: 10.h),

        // عرض الصورة أو الأيقونة
        CustomBackgroundWithWidget(
          height: 60.h,
          width: 60.h,
          color: colors.greyBackgrondHome_darkPrimary,
          borderRadius: 45,
          child: profileImage.isNotEmpty
              ? ClipRRect(
                  borderRadius: BorderRadius.circular(45),
                  child: Image.network(
                    profileImage,
                    fit: BoxFit.cover,
                    width: 60.h,
                    height: 60.h,
                    errorBuilder: (_, __, ___) => Icon(
                      Icons.group,
                      size: 35.h,
                      color: AppColors.greyHintDark,
                    ),
                  ),
                )
              : Icon(
                  Icons.group,
                  size: 35.h,
                  color: AppColors.greyHintDark,
                ),
        ),
      ],
    );
  }
}
