
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:project_manag_ite/controller/nav_bar/home/home_controller.dart';
import 'package:project_manag_ite/core/constant/image_asset.dart';
import 'package:project_manag_ite/view/widget/home/form_submit_widget.dart';

class FormSubmitWidgetRowwww extends StatelessWidget {
  const FormSubmitWidgetRowwww({super.key});

  @override
  Widget build(BuildContext context) {
    final controller = Get.find<HomeControllerImp>();
    return Column(children: [
      // Directionality(
      //         textDirection: TextDirection.rtl,
      //         child: SingleChildScrollView(
      //           scrollDirection: Axis.horizontal,
      //           child: Directionality(
      //             textDirection: TextDirection.ltr,
      //             child: Row(
      //               children: [
      //                 FormSubmitWidget(
      //                   heightMediaQ: MediaQuery.of(context).size.height,
      //                   imageAsset: MyImageAsset.sixthPerson,
      //                   titleText: "طلب انضمام عضو",
      //                   dayCount: "30",
      //                   startDate: "23\\05\\2025",
      //                   endDate: "23\\05\\1111",
      //                 ),
      //                 FormSubmitWidget(
      //                   heightMediaQ: MediaQuery.of(context).size.height,
      //                   imageAsset: MyImageAsset.form2,
      //                   titleText: "تقديم استمارة 2",
      //                   dayCount: "30",
      //                   startDate: "23\\05\\2025",
      //                   endDate: "23\\05\\1111",
      //                 ),
      //                 FormSubmitWidget(
      //                   heightMediaQ: MediaQuery.of(context).size.height,
      //                   imageAsset: MyImageAsset.lamp,
      //                   titleText: "تقديم فكرة مشروع",
      //                   dayCount: "30",
      //                   startDate: "23\\05\\2025",
      //                   endDate: "23\\05\\1111",
      //                 ),
      //               ],
      //             ),
      //           ),
      //         ),
      //       ),
            
            Directionality(
              textDirection: TextDirection.rtl,
              child: SizedBox(
                height: 120.h,
                // height: MediaQuery.of(context).size.height *
                //     0.15, // اضبط الارتفاع المناسب لعنصر FormSubmitWidget
                child: Directionality(
                  textDirection: TextDirection.ltr,
                  child: PageView(
                    controller: controller.pageController,
                    scrollDirection: Axis.horizontal,
                    clipBehavior: Clip.none,
                    children: [
                      FormSubmitWidget(
                        //heightMediaQ: MediaQuery.of(context).size.height,
                        imageAsset: MyImageAsset.sixthPerson,
                        titleText: "طلب انضمام عضو",
                        dayCount: "30",
                        startDate: "23\\05\\2025",
                        endDate: "23\\05\\1111",
                      ),
                      FormSubmitWidget(
                        //heightMediaQ: MediaQuery.of(context).size.height,
                        imageAsset: MyImageAsset.form2,
                        titleText: "تقديم استمارة 2",
                        dayCount: "30",
                        startDate: "23\\05\\2025",
                        endDate: "23\\05\\1111",
                      ),
                      FormSubmitWidget(
                        //heightMediaQ: MediaQuery.of(context).size.height,
                        imageAsset: MyImageAsset.lampOutLine,
                        titleText: "تقديم فكرة مشروع مشروع مشروع مشروع مشروع مشروع",
                        dayCount: "30",
                        startDate: "23\\05\\2025",
                        endDate: "23\\05\\1111",
                      ),
                    ],
                  ),
                ),
              ),
            ),


            // Obx(() => Row(
            //       textDirection: TextDirection.rtl,
            //       mainAxisAlignment: MainAxisAlignment.end,
            //       children: List.generate(3, (index) {
            //         final isActive = controller.currentIndex.value == index;
            //         return AnimatedContainer(
            //           duration: const Duration(milliseconds: 300),
            //           margin: const EdgeInsets.symmetric(horizontal: 4),
            //           width: isActive ? 20 : 8,
            //           height: 8,
            //           decoration: BoxDecoration(
            //             color: isActive ? AppColors.primary : AppColors.grey,
            //             borderRadius: BorderRadius.circular(4),
            //           ),
            //         );
            //       }),
            //     )),
            // Directionality(
            //   textDirection: TextDirection.rtl,
            //   child: SingleChildScrollView(
            //     controller: controller.scrollController, // 👈 تمرير الكونترولر
            //     scrollDirection: Axis.horizontal,
            //     child: Directionality(
            //       textDirection: TextDirection.ltr,
            //       child: Row(
            //         children: [
            //           //SizedBox(width: 10),
            //           FormSubmitWidget(
            //             heightMediaQ: MediaQuery.of(context).size.height,
            //             imageAsset: MyImageAsset.sixthPerson,
            //             titleText: "طلب انضمام عضو",
            //             dayCount: "30",
            //             startDate: "23\\05\\2025",
            //             endDate: "23\\05\\1111",
            //           ),
            //           SizedBox(width: 5),
            //           FormSubmitWidget(
            //             heightMediaQ: MediaQuery.of(context).size.height,
            //             imageAsset: MyImageAsset.form2,
            //             titleText: "تقديم استمارة 2",
            //             dayCount: "30",
            //             startDate: "23\\05\\2025",
            //             endDate: "23\\05\\1111",
            //           ),
            //           SizedBox(width: 5),
            //           FormSubmitWidget(
            //             heightMediaQ: MediaQuery.of(context).size.height,
            //             imageAsset: MyImageAsset.lamp,
            //             titleText: "تقديم فكرة مشروع",
            //             dayCount: "30",
            //             startDate: "23\\05\\2025",
            //             endDate: "23\\05\\1111",
            //           ),
            //           SizedBox(width: 5),
            //         ],
            //       ),
            //     ),
            //   ),
            // ),
    ],);
  }
}

