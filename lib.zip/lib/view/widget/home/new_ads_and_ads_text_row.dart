import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:project_manag_ite/controller/serv/theme_controller.dart';
import 'package:project_manag_ite/core/constant/colors.dart';
import 'package:project_manag_ite/view/widget/home/custom_background_with_child.dart';
import 'package:project_manag_ite/view/widget/onBoaringWidget/custom_title_text.dart';

class NewAdsAndAdsTextRow extends StatelessWidget {
  const NewAdsAndAdsTextRow(
      {super.key,  required this.colors});
  //final double heightMediaQ;
  final CustomAppColors colors;

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        CustomBackgroundWithWidget(
            height: 36.h,
            width: 120.w,
            color: Get.find<ThemeController>().isDark
                ? AppColors.darkPrimary
                : AppColors.redPink,
            borderRadius: 30,
            child: Row(
              children: [
                const Spacer(),
                CustomTitleText(
                    text: "اعلان جديد",
                    isTitle: true,
                    screenHeight: 350.sp,
                    textColor: colors.titleText,
                    horizontalPadding: 10.h,
                    textAlign: TextAlign.center),
                const Spacer(),
                CustomBackgroundWithWidget(
                    height: 26.h,
                    width: 26.w,
                    color: AppColors.red,
                    borderRadius: 30,
                    child: CustomTitleText(
                        text: "99",
                        isTitle: true,
                        screenHeight: 300.sp,
                        textColor: Get.find<ThemeController>().isDark
                            ? AppColors.black
                            : AppColors.white,
                        textAlign: TextAlign.center)),
                const SizedBox(
                  width: 3,
                ),
              ],
            )),
        const Spacer(),
        CustomTitleText(
            text: "قسم الإعلانات",
            isTitle: true,
            screenHeight: 600.sp,
            textColor: colors.titleText,
            textAlign: TextAlign.center)
      ],
    );
  }
}
