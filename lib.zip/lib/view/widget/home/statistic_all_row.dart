
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:project_manag_ite/controller/serv/theme_controller.dart';
import 'package:project_manag_ite/core/constant/colors.dart';
import 'package:project_manag_ite/core/constant/image_asset.dart';
import 'package:project_manag_ite/view/widget/home/statistic_widget.dart';

class StatisticAllRow extends StatelessWidget {
  const StatisticAllRow({super.key});
  

  @override
  Widget build(BuildContext context) {
    return IntrinsicHeight(
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          StatisticWidget(
           // heightMediaQ: MediaQuery.of(context).size.height,
            image: MyImageAsset.statistic3,
            title: "عدد الطلاب",
            titleColor: AppColors.greyHintLight,
            number: "9999",
            numberColor: AppColors.red,
            numberBackgroundColor:
              Get.find<ThemeController>().isDark
              ? AppColors.darkPrimary
             : AppColors.redPink,
          ),
          const VerticalDivider(
            color: AppColors.greyHintLight, // أو أي لون مناسب
            thickness: 1,
            width: 20,
            indent: 10,
            endIndent: 10,
          ),
          StatisticWidget(
            //heightMediaQ: MediaQuery.of(context).size.height,
            image: MyImageAsset.statistic2,
            title: "عدد المجموعات",
            titleColor: AppColors.greyHintLight,
            number: "132",
            numberColor: AppColors.yellow,
            numberBackgroundColor:
            Get.find<ThemeController>().isDark
              ? AppColors.darkPrimary
            : AppColors.yellowWhite,
          ),
          const VerticalDivider(
            color: AppColors.greyHintLight, // أو أي لون مناسب
            thickness: 1,
            width: 20,
            indent: 10,
            endIndent: 10,
          ),
          StatisticWidget(
            //heightMediaQ: MediaQuery.of(context).size.height,
            image: MyImageAsset.statistic1,
            title: "عدد المشرفين",
            titleColor: AppColors.greyHintLight,
            number: "12",
            numberColor: AppColors.cyen,
            numberBackgroundColor:
            Get.find<ThemeController>().isDark
              ? AppColors.darkPrimary
            : AppColors.cyenToWhite,
          ),
        ],
      ),
    );
  }
}
