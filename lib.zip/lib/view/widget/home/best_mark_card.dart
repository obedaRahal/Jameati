import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:project_manag_ite/controller/serv/theme_controller.dart';
import 'package:project_manag_ite/core/constant/colors.dart';
import 'package:project_manag_ite/core/constant/fonts.dart';
import 'package:project_manag_ite/core/constant/image_asset.dart';
import 'package:project_manag_ite/view/widget/home/custom_background_with_child.dart';
import 'package:project_manag_ite/view/widget/onBoaringWidget/custom_title_text.dart';

class BestMarkCard extends StatelessWidget {
  //final double heightMediaQ;
  final String title;
  final String imageAsset;
  final String finalText;
  final String mark;
  final List<String> avatars;

  const BestMarkCard({
    super.key,
    //required this.heightMediaQ,
    required this.title,
    required this.imageAsset,
    required this.finalText,
    required this.mark,
    required this.avatars,
  });

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).extension<CustomAppColors>()!;
    return CustomBackgroundWithWidget(
      height: 150.h,
      width: 365.w,
      color: colors.greyBackgrondHome_darkPrimary,
      borderRadius: 20,
      child: Padding(
        padding: EdgeInsets.symmetric(vertical: 8.w),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.end,
          children: [
            SizedBox(
              width: 220.w,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  // ✅ Scrollable title
                  SingleChildScrollView(
                    scrollDirection: Axis.horizontal,
                    child: Row(
                      children: [
                        CustomTitleText(
                          text: title,
                          isTitle: true,
                          screenHeight: 400.sp,
                          textColor: colors.titleText,
                          textAlign: TextAlign.center,
                        ),
                        SizedBox(
                          width: 3.w,
                        ),
                        Image.asset(
                          MyImageAsset.lamp2,
                          height: 25.h,
                        )
                      ],
                    ),
                  ),

                  // ✅ Final Text & mark
                  CustomBackgroundWithWidget(
                    height: 30.h,
                    width: 280.w,
                    color: Get.find<ThemeController>().isDark
                        ? const Color(0xff3F3F3F)
                        : AppColors.greyInput,
                    borderRadius: 20,
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        CustomBackgroundWithWidget(
                          height: 45.h,
                          width: 70.w,
                          color: colors.primary_cyen,
                          borderRadius: 20,
                          child: Padding(
                            padding: EdgeInsets.symmetric(horizontal: 5.h),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.end,
                              children: [
                                Text(
                                  mark,
                                  style: TextStyle(
                                    fontSize: 18.sp,
                                    fontFamily: MyFonts.hekaya,
                                    color: colors.backgroundWhite,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                                SizedBox(width: 15.w),
                                Container(
                                  height: 23.h,
                                  width: 22.w,
                                  decoration: BoxDecoration(
                                    color: colors.backgroundWhite,
                                    borderRadius: BorderRadius.circular(20),
                                  ),
                                  child: Icon(
                                    Icons.check,
                                    color: AppColors.primary,
                                    size: 22.h,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                        Text(
                          finalText,
                          style: TextStyle(
                            fontSize: 15.sp,
                            fontFamily: MyFonts.hekaya,
                            color: AppColors.greyHintDark,
                          ),
                        ),
                        SizedBox(width: 3.w),
                      ],
                    ),
                  ),

                  // ✅ avatars
                  Container(
                    alignment: Alignment.centerRight,
                    //width: 250.w,
                    child: SingleChildScrollView(
                      scrollDirection: Axis.horizontal,
                      child: Row(
                        children: avatars
                            .map((avatarPath) => Row(
                                  children: [
                                    ClipRRect(
                                      borderRadius: BorderRadius.circular(30),
                                      child: Image.asset(
                                        avatarPath,
                                        height: 35.h,
                                      ),
                                    ),
                                    const SizedBox(width: 3),
                                  ],
                                ))
                            .toList(),
                      ),
                    ),
                  ),
                ],
              ),
            ),

             SizedBox(width: 5.w),

            // ✅ Right image
            ClipRRect(
              borderRadius: BorderRadius.circular(20),
              child: Image.asset(
                imageAsset,
                height: 130.h,
              ),
            ),

            SizedBox(width: 8.w),
          ],
        ),
      ),
    );
  }
}








// CustomBackgroundWithWidget(
//                     height: heightMediaQ * .165,
//                     width: heightMediaQ * .46,
//                     color: AppColors.grey,
//                     borderRadius: 20,
//                     child: Padding(
//                       padding:
//                           EdgeInsets.symmetric(vertical: heightMediaQ * .008),
//                       child: Row(
//                         mainAxisAlignment: MainAxisAlignment.end,
//                         children: [
//                           SizedBox(
//                             width: heightMediaQ * .27,
//                             child: Column(
//                               mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                               crossAxisAlignment: CrossAxisAlignment.end,
//                               children: [
//                                 SingleChildScrollView(
//                                   scrollDirection: Axis.horizontal,
//                                   child: Row(
//                                     children: [
//                                       CustomTitleText(
//                                         text: item["title"],
//                                         isTitle: true,
//                                         screenHeight: heightMediaQ * .65,
//                                         textColor: AppColors.black,
//                                         textAlign: TextAlign.center,
//                                       ),
//                                       Image.asset(
//                                         item["image"],
//                                         height: heightMediaQ * .03,
//                                       )
//                                     ],
//                                   ),
//                                 ),
//                                 CustomBackgroundWithWidget(
//                                   height: heightMediaQ * .032,
//                                   width: heightMediaQ * .28,
//                                   color: AppColors.greyInput,
//                                   borderRadius: 20,
//                                   child: Row(
//                                     mainAxisAlignment:
//                                         MainAxisAlignment.spaceBetween,
//                                     children: [
//                                       CustomBackgroundWithWidget(
//                                         height: heightMediaQ * .045,
//                                         width: heightMediaQ * .09,
//                                         color: AppColors.primary,
//                                         borderRadius: 20,
//                                         child: Padding(
//                                           padding: const EdgeInsets.symmetric(
//                                               horizontal: 6),
//                                           child: Row(
//                                             mainAxisAlignment:
//                                                 MainAxisAlignment.center,
//                                             children: [
//                                               Text(
//                                                 "100",
//                                                 style: TextStyle(
//                                                   fontSize: heightMediaQ * .026,
//                                                   fontFamily: MyFonts.hekaya,
//                                                   color: AppColors.white,
//                                                   fontWeight: FontWeight.bold,
//                                                 ),
//                                               ),
//                                               SizedBox(
//                                                   width: heightMediaQ * .018),
//                                               Container(
//                                                 height: heightMediaQ * .03,
//                                                 width: heightMediaQ * .03,
//                                                 decoration: BoxDecoration(
//                                                   color: AppColors.white,
//                                                   borderRadius:
//                                                       BorderRadius.circular(20),
//                                                 ),
//                                                 child: Icon(
//                                                   Icons.check,
//                                                   color: AppColors.primary,
//                                                 ),
//                                               ),
//                                             ],
//                                           ),
//                                         ),
//                                       ),
//                                       Text(
//                                         item["finalText"],
//                                         style: TextStyle(
//                                           fontSize: heightMediaQ * .022,
//                                           fontFamily: MyFonts.hekaya,
//                                           color: AppColors.greyHintDark,
//                                         ),
//                                       ),
//                                       const SizedBox(width: 3),
//                                     ],
//                                   ),
//                                 ),
//                                 SizedBox(
//                                   width: heightMediaQ * .27,
//                                   child: SingleChildScrollView(
//                                     scrollDirection: Axis.horizontal,
//                                     child: Row(
//                                       children: List.generate(
//                                         6,
//                                         (i) => Row(
//                                           children: [
//                                             ClipRRect(
//                                               borderRadius:
//                                                   BorderRadius.circular(30),
//                                               child: Image.asset(
//                                                 MyImageAsset.obeda,
//                                                 height: 35,
//                                               ),
//                                             ),
//                                             const SizedBox(width: 3),
//                                           ],
//                                         ),
//                                       ),
//                                     ),
//                                   ),
//                                 ),
//                               ],
//                             ),
//                           ),
//                           const SizedBox(width: 5),
//                           ClipRRect(
//                             borderRadius: BorderRadius.circular(20),
//                             child: Image.asset(
//                               MyImageAsset.obeda,
//                               height: 130,
//                             ),
//                           ),
//                           const SizedBox(width: 8),
//                         ],
//                       ),
//                     ),
//                   );