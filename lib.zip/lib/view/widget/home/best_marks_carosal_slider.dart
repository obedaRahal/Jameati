import 'package:carousel_slider/carousel_slider.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:project_manag_ite/controller/nav_bar/home/home_controller.dart';
import 'package:project_manag_ite/core/constant/image_asset.dart';
import 'package:project_manag_ite/data/datasource/static/static.dart';
import 'package:project_manag_ite/view/widget/home/best_mark_card.dart';

class BestMarkCarosalSlider extends StatelessWidget {
  const BestMarkCarosalSlider({super.key});

  @override
  Widget build(BuildContext context) {

    final controller = Get.find<HomeControllerImp>();
    double heightMediaQ = MediaQuery.of(context).size.height;
    return CarouselSlider.builder(
      carouselController: controller.carouselController,
      itemCount: staticSliderData.length,
      itemBuilder: (context, index, realIdx) {
        final item = staticSliderData[index];

        return BestMarkCard(
          //heightMediaQ: MediaQuery.of(context).size.height,
          title: "أفضل مشروع",
          imageAsset: MyImageAsset.obeda,
          finalText: "مرحلي : 999 / نهائي : 99",
          mark: "100",
          avatars: [
            MyImageAsset.obeda,
            MyImageAsset.obeda,
            MyImageAsset.obeda,
            MyImageAsset.obeda,
            MyImageAsset.obeda,
            MyImageAsset.obeda,
          ],
        );
      },
      options: CarouselOptions(
        height: 140, // نفس ارتفاع العنصر
        viewportFraction: heightMediaQ * .0013, // 👈 نفس عرض العنصر
        autoPlay: true,
        reverse: true,
        initialPage: controller.carouselCurrentIndex.value,
        autoPlayAnimationDuration: const Duration(seconds: 1),
        enableInfiniteScroll: false,
        enlargeCenterPage: false, // 👈 إلغاء التكبير
        onPageChanged: (index, reason) {
          controller.carouselCurrentIndex.value = index;
          debugPrint("indexxxxx is $index");
          debugPrint("reason is is $reason");
        },
      ),
    );
  }
}
