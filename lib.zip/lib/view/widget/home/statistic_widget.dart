import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/svg.dart';
import 'package:project_manag_ite/view/widget/home/custom_background_with_child.dart';
import 'package:project_manag_ite/view/widget/onBoaringWidget/custom_title_text.dart';

class StatisticWidget extends StatelessWidget {
  //final double heightMediaQ;
  final String image;
  final String title;
  final Color titleColor;
  final String number;
  final Color numberColor;
  final Color numberBackgroundColor;

  const StatisticWidget({
    super.key,
    //required this.heightMediaQ,
    required this.title,
    required this.titleColor,
    required this.number,
    required this.numberColor,
    required this.image,
    required this.numberBackgroundColor,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 10),
          child: SvgPicture.asset(image),
        ),
        CustomTitleText(
          //horizontalPadding: heightMediaQ * .018,
          text: title,
          isTitle: true,
          screenHeight: 350.sp,
          textAlign: TextAlign.center,
          textColor: titleColor,
        ),
        SizedBox(
          height: 5.h,
        ),
        CustomBackgroundWithWidget(
          height: 24.h,
          width: 45.w,
          color: numberBackgroundColor,
          borderRadius: 20,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              CustomTitleText(
                text: number,
                isTitle: true,
                screenHeight: 300.sp,
                textColor: numberColor,
                textAlign: TextAlign.center,
              ),
            ],
          ),
        ),
      ],
    );
  }
}
