
// import 'package:flutter/material.dart';
// import 'package:get/get.dart';
// import 'package:project_manag_ite/controller/auth/register_controller.dart';
// import 'package:project_manag_ite/core/constant/colors.dart';
// import 'package:project_manag_ite/view/widget/onBoaringWidget/custom_title_text.dart';

// class SpecificationField extends StatelessWidget {
//   const SpecificationField({super.key});

//   @override
//   Widget build(BuildContext context) {
//     final colors = Theme.of(context).extension<CustomAppColors>()!;

//     return Column(
//       crossAxisAlignment: CrossAxisAlignment.end,
//       children: [
//         CustomTitleText(
//           text: "التخصص",
//           isTitle: true,
//           textAlign: TextAlign.right,
//           textColor: colors.titleText,
//           screenHeight: 600, // أي قيمة مناسبة
//           horizontalPadding: 20,
//         ),
//         const SizedBox(height: 5),
//         const SpecificatSelector(),
//       ],
//     );
//   }
// }

// class SpecificatSelector extends StatelessWidget {
//   const SpecificatSelector({super.key});

//   @override
//   Widget build(BuildContext context) {
//     final RegisterControllerImp controller = Get.find();

//     return Obx(() {
//       return Row(
//         mainAxisAlignment: MainAxisAlignment.spaceBetween,
//         children: [
          
          
//           _buildSpecButton("باك ايند", controller ,context),
//           _buildSpecButton("فرونت موبايل", controller ,context),
//           _buildSpecButton("فرونت ويب", controller ,context),
//         ],
//       );
//     });
//   }

//   Widget _buildSpecButton(String title, RegisterControllerImp controller ,context) {
//     final bool isSelected = controller.selectedSpecification.value == title;
//         final colors = Theme.of(context).extension<CustomAppColors>()!;



//     return OutlinedButton(
//       onPressed: () {
//         controller.selectedSpecification.value = title;
//         controller.specification.text = title;
//       },
//       style: OutlinedButton.styleFrom(
//         //elevation: 5,
//         backgroundColor: isSelected ? colors.cyenToWhite_greyInputDark : Colors.transparent,
//         side: isSelected ?BorderSide(width: 2,
//         color: colors.greyInput_greyInputDark
//         ):  BorderSide(
//           color:colors.greyHint_authTabUnselectedText,
//           width: 1,
//         ),
//         shape: RoundedRectangleBorder(
//           borderRadius: BorderRadius.circular(30),
//         ),
//         padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 0),
//       ),
//       child: Text(
//         title,
//         style: TextStyle(
//           color: isSelected ?  colors.primary_cyen
//               : colors.greyHint_authTabUnselectedText,
//           fontWeight: FontWeight.bold,
//           fontSize: 20,
//         ),
//       ),
//     );
//   }
// }



import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:project_manag_ite/controller/auth/register_controller.dart';
import 'package:project_manag_ite/core/constant/colors.dart';

class SpecificatSelector extends StatelessWidget {
  const SpecificatSelector({super.key});

  // ✅ تعريف الخريطة هنا داخل الكلاس
  static const Map<String, String> specMap = {
    "باك ايند": "backend",
    "فرونت موبايل": "front_mobile",
    "فرونت ويب": "front_Web",
  };

  @override
  Widget build(BuildContext context) {
    final RegisterControllerImp controller = Get.find();

    return Obx(() {
      return Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          _buildSpecButton("باك ايند", controller, context),
          _buildSpecButton("فرونت موبايل", controller, context),
          _buildSpecButton("فرونت ويب", controller, context),
        ],
      );
    });
  }

  Widget _buildSpecButton(String title, RegisterControllerImp controller, BuildContext context) {
    final bool isSelected = controller.selectedSpecification.value == title;
    final colors = Theme.of(context).extension<CustomAppColors>()!;
    final String? valueToStore = specMap[title]; // ✅ الآن لن يظهر الخطأ

    return OutlinedButton(
      onPressed: () {
        controller.selectedSpecification.value = title;
        controller.specification.text = valueToStore ?? "";
      },
      style: OutlinedButton.styleFrom(
        backgroundColor: isSelected ? colors.cyenToWhite_greyInputDark : Colors.transparent,
        side: isSelected
            ? BorderSide(width: 2, color: colors.greyInput_greyInputDark)
            : BorderSide(color: colors.greyHint_authTabUnselectedText, width: 1),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(30)),
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 0),
      ),
      child: Text(
        title,
        style: TextStyle(
          color: isSelected ? colors.primary_cyen : colors.greyHint_authTabUnselectedText,
          fontWeight: FontWeight.bold,
          fontSize: 20,
        ),
      ),
    );
  }
}
