import 'package:flutter/material.dart';
import 'package:project_manag_ite/core/constant/colors.dart';

class CustomTextFormFeild extends StatelessWidget {
  const CustomTextFormFeild({
    super.key,
    required this.hintText,
    required this.iconData,
    required this.myComtroller,
    required this.validator,
    required this.isNumber,
    this.obscureText,
    this.onTapIcon
  });

  final String hintText;
  final IconData iconData;
  final TextEditingController myComtroller;
  final String? Function(String?) validator;
  final bool isNumber;
  final bool? obscureText;
  final void Function()? onTapIcon;

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).extension<CustomAppColors>()!;

    return TextFormField(
      obscureText: obscureText == null || obscureText == false ? false : true,
      keyboardType: isNumber ? TextInputType.number : TextInputType.text,
      validator: validator,
      controller: myComtroller,
      cursorColor: AppColors.greyInput,
      decoration: InputDecoration(
        hintText: hintText,
        hintTextDirection: TextDirection.rtl,
        hintStyle: TextStyle(
          color: AppColors.greyHintLight,
          fontSize: MediaQuery.of(context).size.height * .02,
        ),
        fillColor: colors.greyInput_greyInputDark,
        filled: true, // تأكد من أن الخلفية ممتلئة
        contentPadding: EdgeInsets.symmetric(
          vertical: MediaQuery.of(context).size.height * .015,
          horizontal: MediaQuery.of(context).size.height * .025,
        ), // تعديل الحشوات لزيادة الفضاء رأسياً
        prefixIcon: InkWell(
          onTap: onTapIcon,
          child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 15),
          child: Icon(
            iconData,
            color: Colors.grey,
            size: MediaQuery.of(context).size.height * .025,
          ),
        ),),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(30),
          borderSide: BorderSide.none,
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(30),
          borderSide: BorderSide(
              color: colors
                  .primary_cyen), // Use primaryColor from CustomAppColors
        ),
        disabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(30),
          borderSide: const BorderSide(
              color: Colors.grey), // Or any color you want for disabled state
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(30),
          borderSide: BorderSide.none, // No border when enabled and not focused
        ),
        errorBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(30),
          borderSide:const BorderSide(
              color: AppColors.red), // No border when enabled and not focused
        ),
        focusedErrorBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(30),
          borderSide:const BorderSide(
              color: AppColors.red), // No border when enabled and not focused
        ),
        // border: OutlineInputBorder(
        //   borderRadius: BorderRadius.circular(30),
        //   borderSide: BorderSide.none,
        // ),

        // focusedBorder: OutlineInputBorder(
        //   borderRadius: BorderRadius.circular(30),
        //   borderSide: BorderSide(color: colors.mainColor),
        // ),

        // disabledBorder: OutlineInputBorder(
        //   borderRadius: BorderRadius.circular(30),
        //   borderSide: BorderSide(color: colors.mainColor),
        // ),

        // enabledBorder: OutlineInputBorder(
        //   borderRadius: BorderRadius.circular(30),
        //   borderSide: BorderSide(color: Colors.red),
        // ),
      ),
    );
  }
}
