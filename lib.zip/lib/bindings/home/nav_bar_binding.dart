import 'package:get/get.dart';
import 'package:project_manag_ite/controller/nav_bar/home/home_controller.dart';
import 'package:project_manag_ite/controller/nav_bar/nav_bar_controller.dart';

class NavBarBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut<NavBarControllerImpl>(
        () => NavBarControllerImpl());

         Get.lazyPut<HomeControllerImp>(() => HomeControllerImp() , fenix: true);
  }
}