import 'package:get/get.dart';
import 'package:project_manag_ite/controller/nav_bar/chats/chats_controller.dart';

class ChatsBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut<ChatsControllerImp>(
        () => ChatsControllerImp());
  }
}