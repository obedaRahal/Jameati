import 'package:get/get.dart';

abstract class ChatsController extends GetxController {}

class ChatsControllerImp extends ChatsController {
  
}