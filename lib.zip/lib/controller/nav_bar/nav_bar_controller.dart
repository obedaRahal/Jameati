import 'package:flutter/cupertino.dart';
import 'package:get/get.dart';
import 'package:project_manag_ite/view/screen/home/chats_screen.dart';
import 'package:project_manag_ite/view/screen/home/home_screen.dart';

abstract class NavBarController extends GetxController {
  changePage(int currentPage);
}

class NavBarControllerImpl extends NavBarController {
  int currentPage = 0;
  List<Widget> listPage = [
    // const Column(
    //   mainAxisAlignment: MainAxisAlignment.center,
    //   children: [
    //     Center(
    //       child: Text('1'),
    //     )
    //   ],
    // ),
    HomeScreen(),


    ChatsScreen(),
    // const Column(
    //   mainAxisAlignment: MainAxisAlignment.center,
    //   children: [
    //     Center(
    //       child: Text('2'),
    //     )
    //   ],
    // ),

    const Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Center(
          child: Text('3'),
        )
      ],
    ),

    const Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Center(
          child: Text('4'),
        )
      ],
    ),
  ];

  @override
  changePage(int i) {
    // If switching to a new tab, delete the controller if it exists
    // if (currentPage != i) {
    //   Get.delete<HomeControllerImp>(force: true);
    // }
    currentPage = i;
    update();
  }
}
