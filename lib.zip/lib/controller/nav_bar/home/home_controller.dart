import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:carousel_slider/carousel_slider.dart';

class HomeController extends GetxController {}

class HomeControllerImp extends HomeController {
  late PageController pageController;

  late CarouselSliderController carouselController = CarouselSliderController();
  RxInt carouselCurrentIndex = 0.obs;

  RxInt selectedYear = 2024.obs;

  @override
  void onInit() {
    pageController = PageController(
      initialPage: 2,
    );

    carouselController = CarouselSliderController();

    super.onInit();
  }
}
